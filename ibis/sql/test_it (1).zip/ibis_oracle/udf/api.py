import collections
import inspect
import itertools
from textwrap import dedent

import sqlalchemy as sa
from sqlalchemy.dialects.oracle import dialect as sa_oracle_dialect

import ibis.expr.rules as rlz
import ibis.udf.validate as v
from ibis import IbisError
from ibis.expr.signature import Argument as Arg
from ibis.sql.ibis_oracle.alchemy import _to_sqla_type
from ibis.sql.ibis_oracle.compiler import (
    OracleExprTranslator,
    OracleUDFNode,
    add_operation,
)

_udf_name_cache = collections.defaultdict(itertools.count)


class OracleUDFError(IbisError):
    pass


def ibis_to_ol_sa_type(ibis_type):
    """Map an ibis DataType to a Oracle-compatible sqlalchemy type"""
    return _to_sqla_type(ibis_type, type_map=OracleExprTranslator._type_map)


def sa_type_to_oracle_str(sa_type):
    """Map a Oracle-compatible sqlalchemy type to a Oracle-appropriate
    string"""
    if callable(sa_type):
        sa_type = sa_type()
    return sa_type.compile(dialect=sa_oracle_dialect())


def ibis_to_oracle_str(ibis_type):
    """Map an ibis DataType to a Oracle-appropriate string"""
    return sa_type_to_oracle_str(ibis_to_ol_sa_type(ibis_type))


#######################################################################
def create_udf_node(name, fields):
    """Create a new UDF node type.

    Parameters
    ----------
    name : str
        Then name of the UDF node
    fields : OrderedDict
        Mapping of class member name to definition

    Returns
    -------
    type
        A new OracleUDFNode subclass
    """
    definition = next(_udf_name_cache[name])
    external_name = '{}_{:d}'.format(name, definition)
    return type(external_name, (OracleUDFNode,), fields)


#######################################################################
def existing_udf(name, input_types, output_type, schema=None, parameters=None):
    """Create an ibis function that refers to an existing Oracle UDF already
    defined in database

    Parameters
    ----------
    name: str
    input_types : List[DataType]
    output_type : DataType
    schema: str - optionally specify the schema that the UDF is defined in
    parameters: List[str] - give names to the arguments of the UDF

    Returns
    -------
    Callable
        The wrapped function
    """

    if parameters is None:
        parameters = ['v{}'.format(i) for i in range(len(input_types))]
    elif len(input_types) != len(parameters):
        raise ValueError(
            (
                "Length mismatch in arguments to existing_udf: "
                "len(input_types)={}, len(parameters)={}"
            ).format(len(input_types), len(parameters))
        )

    v.validate_output_type(output_type)

    udf_node_fields = collections.OrderedDict(
        [
            (name, Arg(rlz.value(type_)))
            for name, type_ in zip(parameters, input_types)
        ]
        + [
            (
                'output_type',
                lambda self, output_type=output_type: rlz.shape_like(
                    self.args, dtype=output_type
                ),
            )
        ]
    )
    udf_node_fields['resolve_name'] = lambda self: name

    udf_node = create_udf_node(name, udf_node_fields)

    def _translate_udf(t, expr):
        func_obj = sa.func
        if schema is not None:
            func_obj = getattr(func_obj, schema)
        func_obj = getattr(func_obj, name)

        sa_args = [t.translate(arg) for arg in expr.op().args]

        return func_obj(*sa_args)

    add_operation(udf_node, _translate_udf)

    def wrapped(*args, **kwargs):
        node = udf_node(*args, **kwargs)
        return node.to_expr()

    return wrapped



