import ibis.expr.operations as ops


class PySparkTable(ops.DatabaseTable):
    pass
