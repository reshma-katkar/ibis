"""OmniSciDB unit tests module."""
